{{- define "rondb.imagePullSecrets" -}}
{{- if $.Values.imagePullSecrets }}
imagePullSecrets:
{{- range $.Values.imagePullSecrets }}
  - name: {{ .name }}
{{- end }}
{{- end }}
{{- end }}

# Could be that there is no repository (e.g. docker.io/alpine)
{{- define "image_repository" -}}
{{- if or (not .image.repository) (eq .image.repository "") -}}
{{- else -}}
{{ .image.repository }}/
{{- end -}}
{{- end -}}

{{- define "image_address" -}}
{{ .image.registry }}/{{ include "image_repository" (dict "image" .image ) }}{{ .image.name }}:{{ .image.tag }}
{{- end -}}

{{- define "rondb.PodSecurityContext" }}
{{- if $.Values.enableSecurityContext }}
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  fsGroup: 1000
  seccompProfile:
    type: RuntimeDefault
{{- end }}
{{- end }}

{{- define "rondb.ContainerSecurityContext" }}
{{- if $.Values.enableSecurityContext }}
securityContext:
  allowPrivilegeEscalation: false
  privileged: false
  capabilities:
    drop:
      - ALL
{{- if .addSysNice }}
    add:
      - SYS_NICE
{{- end }}
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: null
  seccompProfile:
    type: RuntimeDefault
{{- end }}
{{- end }}

{{- define "rondb.nodeSelector" -}}
{{- if and .nodeSelector (not (empty .nodeSelector) )}}
nodeSelector: {{ .nodeSelector | toYaml | nindent 2 }}
{{- end }}
{{- end -}}

{{- define "rondb.tolerations" -}}
{{- if and .tolerations (not (empty .tolerations) )}}
tolerations: {{ .tolerations | toYaml | nindent 2 }}
{{- end }}
{{- end -}}

{{- define "rondb.serviceAccountAnnotations" -}}
{{- if $.Values.serviceAccountAnnotations }}
annotations: {{ $.Values.serviceAccountAnnotations | toYaml | nindent 2 }}
{{- end }}
{{- end -}}

{{ define "rondb.storageClass.default" -}}
{{ if .Values.resources.requests.storage.classes.default  }}
storageClassName: {{ .Values.resources.requests.storage.classes.default | quote }}
{{ end }}
{{- end }}

{{ define "rondb.storageClass.mgmd" -}}
{{ if .Values.resources.requests.storage.classes.mgmd }}
storageClassName: {{ .Values.resources.requests.storage.classes.mgmd | quote }}
{{- else }}
{{ include "rondb.storageClass.default" . }}
{{ end }}
{{- end }}

{{ define "rondb.storageClass.diskColumns" -}}
{{ if .Values.resources.requests.storage.classes.diskColumns }}
storageClassName: {{ .Values.resources.requests.storage.classes.diskColumns | quote }}
{{- else }}
{{ include "rondb.storageClass.default" . }}
{{ end }}
{{- end }}

{{ define "rondb.ndbmtd.storageSize" -}}
{{- $ := .root }}
{{- if include "rondb.isInstall" $ }}
{{- $memoryGiB := div $.Values.resources.limits.memory.ndbmtdsMiB 1024 | int }}
{{- /* mulf, not mul: sprig's integer functions truncate every argument,
so (mul $memoryGiB 2.25) is 2 x memory and under-counts the LCP budget. */}}
{{- $requiredStorage := add
    (mulf $memoryGiB 2.25 | ceil | int)
    $.Values.resources.requests.storage.redoLogGiB
    (mul $.Values.resources.requests.storage.undoLogsGiB 2)
    $.Values.resources.requests.storage.logGiB
}}
{{- if not $.Values.resources.requests.storage.classes.diskColumns }}
{{- /* "=" not ":=": a ":=" here would declare a new variable scoped to this
if-block and the addition would never reach the comparison below. */}}
{{- $requiredStorage = add
  $requiredStorage
  $.Values.resources.requests.storage.diskColumnGiB
}}
{{- end }}
{{- /* The filesystem takes its own share of the volume (~1.6% inode tables
plus the journal on ext4): the same 3% + 2 GiB margin as the dedicated
disk-column volume (RONDB-1154). */}}
{{- $fsOverheadGiB := add (div (mul (int $.Values.resources.requests.storage.ndbmtdGiB) 3) 100) 2 }}
{{- if gt (add $requiredStorage $fsOverheadGiB) (int $.Values.resources.requests.storage.ndbmtdGiB) }}
# Validate that the requested storage is enough for the different components
{{ fail (printf "The requested storage size %dGiB is not enough for the ndbmtds. Required: %dGiB plus %dGiB filesystem overhead" (int $.Values.resources.requests.storage.ndbmtdGiB) $requiredStorage $fsOverheadGiB) }}
{{- end }}
  storage: {{ $.Values.resources.requests.storage.ndbmtdGiB | int }}Gi
{{- else }}
{{- $statefulSetName := printf "node-group-%d" .nodeGroup }}
{{- $sts := lookup "apps/v1" "StatefulSet" $.Release.Namespace $statefulSetName }}
{{- if $sts }}
{{- $claim := index $sts.spec.volumeClaimTemplates 0 }}
{{- $size := $claim.spec.resources.requests.storage }}
  storage: {{ $size }} # In case of an upgrade use the existing value
{{- else }}
  # Fallback to the value set via values.yaml
  storage: {{ $.Values.resources.requests.storage.ndbmtdGiB | int }}Gi
{{- end }}
{{- end }}
{{- end }}

{{ define "rondb.ndbmtd.diskColumnStorageSize" -}}
{{- $ := .root }}
{{- $diskColumnGiB := int $.Values.resources.requests.storage.diskColumnGiB }}
{{- /* Filesystem overhead grows with the volume: ~1.6% inode tables plus the
journal on ext4. 3% + 2 GiB keeps the diskColumnGiB tablespace file within
the usable capacity (RONDB-1154). */}}
{{- $computedGiB := add $diskColumnGiB (div (mul $diskColumnGiB 3) 100) 2 }}
{{- if include "rondb.isInstall" $ }}
  storage: {{ $computedGiB }}Gi
{{- else }}
{{- $statefulSetName := printf "node-group-%d" .nodeGroup }}
{{- $sts := lookup "apps/v1" "StatefulSet" $.Release.Namespace $statefulSetName }}
{{- if $sts }}
{{- $existingSize := "" }}
{{- range $claim := $sts.spec.volumeClaimTemplates }}
{{- if eq $claim.metadata.name "rondb-ndbmtd-dc" }}
{{- $existingSize = $claim.spec.resources.requests.storage }}
{{- end }}
{{- end }}
{{- if $existingSize }}
  storage: {{ $existingSize }} # In case of an upgrade use the existing value
{{- else }}
{{ fail (printf "StatefulSet %s exists without a rondb-ndbmtd-dc volume claim. Enabling resources.requests.storage.classes.diskColumns on an existing cluster is not supported: Kubernetes does not allow adding volumeClaimTemplates to a StatefulSet." $statefulSetName) }}
{{- end }}
{{- else }}
  # Fallback to the value computed from values.yaml
  storage: {{ $computedGiB }}Gi
{{- end }}
{{- end }}
{{- end }}

{{ define "rondb.storageClass.binlogs" -}}
{{ if .Values.resources.requests.storage.classes.binlogFiles }}
storageClassName: {{ .Values.resources.requests.storage.classes.binlogFiles | quote }}
{{- else }}
{{ include "rondb.storageClass.default" . }}
{{ end }}
{{- end }}

{{/*
Wait until every node group has a started ndbmtd, then for at most
timeoutsMinutes.waitAllDatanodes until every active ndbmtd is started. For
consumers that only need an operational cluster: MySQLds and SQL Jobs.

The setting may be absent: "helm upgrade --reuse-values" of a release
installed with an older chart keeps that chart's values, which lack it. It
then defaults to 2 minutes, as in values.yaml. Checks presence rather than
using "default", so that an explicit 0 is kept.
*/}}
{{- define "rondb.container.waitDatanodes" -}}
{{- $minutes := 2 -}}
{{- if hasKey .Values.timeoutsMinutes "waitAllDatanodes" -}}
{{- $minutes = .Values.timeoutsMinutes.waitAllDatanodes -}}
{{- end -}}
{{- include "rondb.container.waitDatanodesCommon" (dict "root" . "waitAllSeconds" (mul (int $minutes) 60)) -}}
{{- end }}

{{/*
Wait, without a time limit, until every active ndbmtd is started. For
consumers that act on every ndbmtd (restore) or set up a new cluster.
*/}}
{{- define "rondb.container.waitAllDatanodes" -}}
{{- include "rondb.container.waitDatanodesCommon" (dict "root" . "waitAllSeconds" "") -}}
{{- end }}

{{- define "rondb.container.waitDatanodesCommon" -}}
{{- $root := .root -}}
- name: wait-datanodes-dependency
  image: {{ include "image_address" (dict "image" $root.Values.images.rondb) }}
{{ include "rondb.ContainerSecurityContext" $root | indent 2 }}
  imagePullPolicy: {{ $root.Values.imagePullPolicy }}
  command:
  - /bin/bash
  - -c
  - |
{{ tpl ($root.Files.Get "files/scripts/wait_ndbmtds.sh") $root | indent 4 }}
  env:
  - name: MGMD_HOSTNAME
    value: {{ include "rondb.mgmdHostname" $root }}
  - name: WAIT_ALL_DATANODES_SECONDS
    value: {{ .waitAllSeconds | quote }}
  resources:
    limits:
      cpu: 0.3
      memory: 100Mi
{{- end }}

{{- define "rondb.container.waitManagement" -}}
- name: wait-management-dependency
  image: {{ include "image_address" (dict "image" .Values.images.rondb) }}
{{ include "rondb.ContainerSecurityContext" $ | indent 2 }}
  imagePullPolicy: {{ $.Values.imagePullPolicy }}
  command:
  - /bin/bash
  - -c
  - |
{{ tpl (.Files.Get "files/scripts/wait_mgmd.sh") . | indent 4 }}
  env:
  - name: MGMD_HOSTNAME
    value: {{ include "rondb.mgmdHostname" . }}
  resources:
    limits:
      cpu: 0.3
      memory: 100Mi
{{- end }}

{{- define "rondb.container.waitRestore" -}}
{{- if include "rondb.restoreFromBackup.backupId" $ }}
- name: wait-restore-backup
  image: {{ include "image_address" (dict "image" $.Values.images.toolbox) }}
  imagePullPolicy: {{ $.Values.imagePullPolicy }}
{{ include "rondb.ContainerSecurityContext" $ | indent 2 }}
  command:
  - /bin/bash
  - -c
  - |
    echo "Waiting for restore-backup Job to have completed"
    set -e

    (set -x; kubectl wait \
      -n {{ .Release.Namespace }} \
      --for=condition=complete \
      --timeout={{ .Values.timeoutsMinutes.restoreNativeBackup }}m \
      job/{{ include "rondb.restoreNativeBackupJobname" . }})          

    echo "Restore Job has completed successfully"
  resources:
    limits:
      cpu: 0.3
      memory: 100Mi
{{- end }}
{{- end }}

{{- define "rondb.apiInitContainer" -}}
- name: cluster-dependency-check
  image: {{ include "image_address" (dict "image" .Values.images.rondb) }}
  imagePullPolicy: {{ $.Values.imagePullPolicy }}
{{ include "rondb.ContainerSecurityContext" $ | indent 2 }}
  command:
  - /bin/bash
  - -c
  - |
{{ tpl (.Files.Get "files/scripts/apis.sh") . | indent 4 }}
  env:
  - name: MGMD_HOSTNAME
    value: {{ include "rondb.mgmdHostname" . }}
  - name: MYSQLD_SERVICE_HOSTNAME
    value: {{ include "rondb.mysqldServiceHostname" . }}
  - name: MYSQL_CLUSTER_USER
    value: {{ .Values.mysql.clusterUser }}
  - name: MYSQL_CLUSTER_PASSWORD
    valueFrom:
      secretKeyRef:
        key: {{ .Values.mysql.clusterUser }}
        name: {{ $.Values.mysql.credentialsSecretName }}
{{- end }}

{{- define "rondb.arrayToCsv" -}}
{{- if .array }}
{{- $length := len .array -}}
{{- range $index, $element := .array -}}
{{- $element }}{{- if lt $index (sub $length 1) }},{{ end -}}
{{- end }}
{{- end }}
{{- end }}

{{- define "rondb.takeBackupPathPrefix" }}
{{- .Values.backups.pathPrefix | default "rondb_backup" }}
{{- end }}

{{- define "rondb.restoreBackupPathPrefix" }}
{{- .Values.restoreFromBackup.pathPrefix | default "rondb_backup" }}
{{- end }}

{{- define "rondb.affinity.preferred.ndbdAZs" }}
# Try to place Pods into same AZs as data nodes for low latency
- weight: 90
  podAffinityTerm:
    topologyKey: topology.kubernetes.io/zone
    labelSelector:
      matchExpressions:
      - key: nodeGroup
        operator: In
        values:
{{- range $nodeGroup := until ($.Values.clusterSize.numNodeGroups | int) }}
        - {{ $nodeGroup | quote }}
{{ end }}
{{- end }}

{{- define "rondb.backups.backupIdFile" -}}
/home/hopsworks/backup-id/id
{{- end -}}

# Backup Id format $(date +'%y%V%u%H%M')
# %y Last two digits of the year
# %V ISO week number (01–53)
# %u Day of the week (1 = Monday, 7 = Sunday)
# %H Hour (00–23)
# %M Minute (00–59)
{{- define "rondb.backups.defineBackupIdEnv" }}
BACKUP_FILE={{ include "rondb.backups.backupIdFile" . | quote}}
if [ -f "$BACKUP_FILE" ]; then
  BACKUP_ID=$(cat "$BACKUP_FILE")
  echo "Reusing existing backup ID: $BACKUP_ID"
else
  BACKUP_ID=$(date +'%y%V%u%H%M')
  echo "$BACKUP_ID" > "$BACKUP_FILE"
  echo "Generated new backup ID: $BACKUP_ID"
fi
{{- end }}

{{- define "rondb.certManager.certificate.endToEnd" }}
{{- if and 
    .endToEndTls.enabled 
    (not .endToEndTls.supplyOwnSecret)
}}
# Certificates will prompt the cert-manager to create a TLS Secret using the referenced
# Issuer.
apiVersion: cert-manager.io/v1
kind: Certificate
metadata:
  name: {{ required "A Certificate must specify a name" .certName }}
  namespace: {{ $.Release.Namespace }}
spec:
  secretName: {{ .endToEndTls.secretName }}
  duration: 2160h # 90d
  renewBefore: 360h # 15d
  dnsNames:
{{ required "A Certificate must contain dnsNames" .dnsNames | toYaml | indent 4 }}
  issuerRef:
    name: {{ include "rondb.certManager.issuer" $ }}
    kind: Issuer
---
{{ end }}
{{- end }}

# This is an easy way to trigger rolling restarts of all RonDB Pods
{{- define "rondb.configIniHash" -}}
{{ mustRegexReplaceAll "NodeActive *=.*" (tpl ($.Files.Get "files/configs/config.ini") $) "" | sha256sum }}
{{- end -}}

# Identifies the release this render asks for. It is stamped on the StatefulSets
# and on the mysqld-configs ConfigMap, so a client can tell that a StatefulSet
# has received this render before trusting `kubectl rollout status`, which
# reports an unpatched StatefulSet as complete. The install/upgrade mode is part
# of it because the pod templates depend on it (rondb.container.waitSingleSetup),
# so the first upgrade after an install restarts the MySQL servers with the chart
# version and values unchanged. Keep it out of pod templates: it changes with
# every value, and there it would restart RonDB each time.
{{- define "rondb.rolloutTarget" -}}
{{- $mode := dict "isInstall" (include "rondb.isInstall" $) "isUpgrade" (include "rondb.isUpgrade" $) -}}
{{ dict "chartVersion" $.Chart.Version "values" $.Values "mode" $mode | mustToJson | sha256sum }}
{{- end -}}

# MaxDMLOperationsPerTransaction cannot exceed MaxNoOfConcurrentOperations
{{- define "rondb.validatedMaxDMLOperationsPerTransaction" -}}
{{- $dml := (.Values.rondbConfig.MaxDMLOperationsPerTransaction | default 32768) | int -}}
{{- $conc := (.Values.rondbConfig.MaxNoOfConcurrentOperations | default 65536) | int -}}
{{- if le $dml $conc }}
{{- $dml -}}
{{- end -}}
{{- end -}}

{{- define "rondb.isAWS" -}}
{{- if and .Values.global .Values.global._hopsworks (eq (upper .Values.global._hopsworks.cloudProvider) "AWS") -}}
true
{{- end -}}
{{- end -}}

{{- define "rondb.isExternallyManaged" -}}
{{- if and .Values.global .Values.global._hopsworks.externalServices .Values.global._hopsworks.externalServices.rondb .Values.global._hopsworks.externalServices.rondb.external -}}
true
{{- end -}}
{{- end -}}

{{- define "rondb.isInstall" -}}
{{- if .Values.mode -}}
{{- if eq .Values.mode "install" -}}
true
{{- else if and (eq .Values.mode "auto") .Release.IsInstall -}}
true
{{- end -}}
{{- else if and .Values.global  .Values.global._hopsworks .Values.global._hopsworks.mode -}}
{{- if eq .Values.global._hopsworks.mode "install" -}}
true
{{- else if and (eq .Values.global._hopsworks.mode "auto") .Release.IsInstall -}}
true
{{- end -}}
{{- else -}}
{{- if .Release.IsInstall -}}
true
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "rondb.isUpgrade" -}}
{{- if .Values.mode -}}
{{- if eq .Values.mode "upgrade" -}}
true
{{- else if and (eq .Values.mode "auto") .Release.IsUpgrade -}}
true
{{- end -}}
{{- else if and .Values.global  .Values.global._hopsworks .Values.global._hopsworks.mode -}}
{{- if eq .Values.global._hopsworks.mode "upgrade" -}}
true
{{- else if and (eq .Values.global._hopsworks.mode "auto") .Release.IsUpgrade -}}
true
{{- end -}}
{{- else -}}
{{- if .Release.IsUpgrade -}}
true
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
  Whether the sequenced data node rollout is turned on.
  Gates BOTH the partition freeze on the node-group StatefulSets and the
  rollout CronJob together — they must always render as a pair: a freeze
  with no CronJob blocks upgrades forever, and a CronJob with no freeze
  does nothing.

  Off with a single node group: there is only one group, and a StatefulSet
  already restarts its pods one at a time, so sequencing would only add
  delay. numNodeGroups can't change after install
  (topology-immutability.yaml), so this stays settled for the cluster's life.

  Off during an in-place restore: that restore scales the node-group
  StatefulSets to zero, and a pod recreated below a frozen partition comes
  back on the OLD pod template — skipping the
  FORCE_INITIAL_START/INPLACE_BACKUP_ID settings the restore needs.
*/}}
{{- define "rondb.ndbmtdSequencedRollout.isActive" -}}
{{- if and
    .Values.ndbmtdSequencedRollout.enabled
    (gt (int .Values.clusterSize.numNodeGroups) 1)
    (not (include "rondb.isExternallyManaged" .))
    (not (include "rondb.restoreFromBackup.isInPlace" .)) -}}
true
{{- end -}}
{{- end -}}

{{/*
  How long (minutes) one node group may take before the rollout flags it as
  stalled. 0 (the default) works it out from the startup probe: one node's
  allowed startup time (timeoutsMinutes.ndbmtdStartupProbe) times the number
  of replicas started one after another, plus 30 minutes of slack.
*/}}
{{- define "rondb.ndbmtdSequencedRollout.perGroupStallTimeoutMinutes" -}}
{{- $derived := add (mul (int .Values.clusterSize.activeDataReplicas) (int .Values.timeoutsMinutes.ndbmtdStartupProbe)) 30 -}}
{{- default $derived .Values.ndbmtdSequencedRollout.perGroupStallTimeoutMinutes -}}
{{- end -}}

{{/*
  Whether the CronJob suspends itself while idle. This ALSO gates the wake
  hook that re-enables it (they must always render as a pair). Active only
  when Helm drives the apply (mode auto/unset): under Argo (mode set) the
  CronJob stays scheduled and no-ops when idle instead, so nothing ever
  writes .spec.suspend and there is no server-side-apply two-writer conflict.
*/}}
{{- define "rondb.ndbmtdSequencedRollout.suspendWhenIdleActive" -}}
{{- if and
    .Values.ndbmtdSequencedRollout.suspendWhenIdle
    (include "rondb.canUseLookupFunc" (dict "mode" .Values.mode "global" .Values.global)) -}}
true
{{- end -}}
{{- end -}}

{{- define "rondb.canUseLookupFunc" -}}
{{- if .mode -}}
{{- if eq .mode "auto" -}}
true
{{- end -}}
{{- else if and .global .global._hopsworks .global._hopsworks.mode -}}
{{- if eq .global._hopsworks.mode "auto" -}}
true
{{- end -}}
{{- else -}}
true
{{- end -}}
{{- end -}}

{{- define "rondb.backup.credentials" -}}
{{- if or (eq .backupConfig.objectStorageProvider "s3") (include "rondb.global.managedObjectStorage.s3" .) (include "rondb.global.minio" .)}}
{{- $secretName := "" }}
{{- $key := "" }}
{{- if and .backupConfig.s3.keyCredentialsSecret.name .backupConfig.s3.keyCredentialsSecret.key }}
{{- $secretName = .backupConfig.s3.keyCredentialsSecret.name }}
{{- $key = .backupConfig.s3.keyCredentialsSecret.key  }}
{{- else if and (include "rondb.global.managedObjectStorage.s3" .) .global._hopsworks.managedObjectStorage.s3.secret .global._hopsworks.managedObjectStorage.s3.secret.name .global._hopsworks.managedObjectStorage.s3.secret.access_key_id}}
{{- $secretName = .global._hopsworks.managedObjectStorage.s3.secret.name }}
{{- $key = .global._hopsworks.managedObjectStorage.s3.secret.access_key_id }}
{{- end }}
{{- $setEnv := and $secretName $key }}
{{- if include "rondb.canUseLookupFunc" . }}
{{- $setEnv = and $setEnv (lookup "v1" "Secret" .namespace $secretName ) }}
{{- end }}
{{- if $setEnv }}
- name: AWS_ACCESS_KEY_ID
  valueFrom:
    secretKeyRef:
      name: {{ $secretName }}
      key: {{ $key }}
{{- else if include "rondb.global.minio" . }}
- name: AWS_ACCESS_KEY_ID
  value: {{ .global._hopsworks.minio.user }}
{{- end }}
{{- if and .backupConfig.s3.secretCredentialsSecret.name .backupConfig.s3.secretCredentialsSecret.key }}
{{- $secretName = .backupConfig.s3.secretCredentialsSecret.name }}
{{- $key = .backupConfig.s3.secretCredentialsSecret.key  }}
{{- else if and (include "rondb.global.managedObjectStorage.s3" .) .global._hopsworks.managedObjectStorage.s3.secret .global._hopsworks.managedObjectStorage.s3.secret.name .global._hopsworks.managedObjectStorage.s3.secret.secret_key_id}}
{{- $secretName = .global._hopsworks.managedObjectStorage.s3.secret.name }}
{{- $key = .global._hopsworks.managedObjectStorage.s3.secret.secret_key_id }}
{{- else if include "rondb.global.minio" . }}
{{- $secretName = "aws-credentials" }}
{{- $key = "secret-access-key" }}
{{- end }}
{{- $setEnv = and $secretName $key }}
{{- if include "rondb.canUseLookupFunc" . }}
{{- $setEnv = and $setEnv (lookup "v1" "Secret" .namespace $secretName ) }}
{{- end }}
{{- if $setEnv }}
- name: AWS_SECRET_ACCESS_KEY
  valueFrom:
    secretKeyRef:
      name: {{ $secretName }}
      key: {{ $key }}
{{- else if include "rondb.global.minio" . }}
- name: AWS_SECRET_ACCESS_KEY
  value: {{ .global._hopsworks.minio.password }}
{{- end }}
{{- end }}
{{- end -}}

{{- define "rondb.global.managedObjectStorage" -}}
{{- if and .global .global._hopsworks .global._hopsworks.managedObjectStorage .global._hopsworks.managedObjectStorage.enabled -}}
true
{{- end -}}
{{- end -}}

{{- define "rondb.global.minio" -}}
{{- if and .global .global._hopsworks .global._hopsworks.minio .global._hopsworks.minio.enabled .global._hopsworks.minio.hopsfs .global._hopsworks.minio.hopsfs.enabled -}}
true
{{- end -}}
{{- end -}}

{{- define "rondb.global.managedObjectStorage.s3" -}}
{{- if and (include "rondb.global.managedObjectStorage" .) .global._hopsworks.managedObjectStorage.s3  -}}
true
{{- end -}}
{{- end -}}

{{- define "rondb.global.backupsEnabled" -}}
{{- if and ( or (include  "rondb.global.managedObjectStorage" (dict "global" .Values.global))  (include  "rondb.global.minio" (dict "global" .Values.global))) .Values.global._hopsworks.backups (hasKey .Values.global._hopsworks.backups "enabled" ) -}}
{{- if .Values.global._hopsworks.backups.enabled -}}
true
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "rondb.backups.isEnabled" -}}
{{- if and (hasKey .Values.backups "enabled") (not (eq .Values.backups.enabled nil)) -}}
{{- if .Values.backups.enabled -}}
true
{{- end -}}
{{- else if include "rondb.global.backupsEnabled" . -}}
true
{{- end -}}
{{- end -}}

{{- define "rondb.backups.schedule" -}}
{{- if and .Values.backups.enabled .Values.backups.schedule -}}
{{- .Values.backups.schedule -}}
{{- else if and (include "rondb.global.backupsEnabled" .) .Values.global._hopsworks.backups.schedule -}}
{{- .Values.global._hopsworks.backups.schedule -}}
{{- else -}}
@weekly
{{- end -}}
{{- end -}}

# FIXME should be changed when supporting multiple storage backends
{{- define "rondb.backups.bucketName" -}}
{{- if .backupConfig.s3.bucketName -}}
{{- .backupConfig.s3.bucketName -}}
{{- else if and (include "rondb.global.managedObjectStorage.s3" .) .global._hopsworks.managedObjectStorage.s3.bucket.name -}}
{{- .global._hopsworks.managedObjectStorage.s3.bucket.name -}}
{{- else if and (include "rondb.global.minio" .) .global._hopsworks.minio.hopsfs.bucket -}}
{{- .global._hopsworks.minio.hopsfs.bucket -}}
{{- else -}}
{{- fail "Missing bucket name configuration for backups. Please specify the bucket name either in the Rondb subchart or under global._hopsworks.managedObjectStorage." }}
{{- end -}}
{{- end -}}


{{- define "rondb.rcloneConfig" -}}
{{- if include "rondb.global.minio" . }}
type = s3
env_auth = true
storage_class = STANDARD
region = {{ .global._hopsworks.minio.region }}
provider = Other
endpoint = http://minio.service.consul:9000
{{- else if or (eq .backupConfig.objectStorageProvider "s3") (include "rondb.global.managedObjectStorage.s3" .) }}
type = s3
env_auth = true
storage_class = STANDARD
{{- if .backupConfig.s3.provider }}
provider = {{ .backupConfig.s3.provider }}
{{- else if and .global .global._hopsworks (eq (upper .global._hopsworks.cloudProvider) "AWS")}}
provider = AWS
{{- else }}
provider = Other
{{- end }}
{{- if .backupConfig.s3.region }}
region = {{ .backupConfig.s3.region }}
{{- else if and (include "rondb.global.managedObjectStorage.s3" .) .global._hopsworks.managedObjectStorage.s3.region }}
region = {{ .global._hopsworks.managedObjectStorage.s3.region }}
{{- end }}
{{- if .backupConfig.s3.serverSideEncryption }}
server_side_encryption = {{ .backupConfig.s3.serverSideEncryption }}
{{- else if and (include "rondb.global.managedObjectStorage.s3" .) .global._hopsworks.managedObjectStorage.s3.serverSideEncryption }}
server_side_encryption = {{ .global._hopsworks.managedObjectStorage.s3.serverSideEncryption }}
{{- end }}
{{- if .backupConfig.s3.endpoint }}
endpoint = {{ .backupConfig.s3.endpoint }}
{{- else if and (include "rondb.global.managedObjectStorage.s3" .) .global._hopsworks.managedObjectStorage.s3.endpoint }}
endpoint = {{ .global._hopsworks.managedObjectStorage.s3.endpoint }}
{{- end }}
{{- end }}
{{- end -}}

{{- define "rondb.restoreFromBackup.backupId" -}}
{{- if .Values.restoreFromBackup.backupId -}}
{{- .Values.restoreFromBackup.backupId  -}}
{{- else if and (or (include "rondb.global.managedObjectStorage" (dict "global" .Values.global)) (include "rondb.global.minio" (dict "global" .Values.global))) .Values.global._hopsworks.restoreFromBackup .Values.global._hopsworks.restoreFromBackup.backupId -}}
{{- .Values.global._hopsworks.restoreFromBackup.backupId -}}
{{- end -}}
{{- end -}}

{{- define "rondb.restoreFromBackup.inPlace" -}}
{{- if not (eq .Values.restoreFromBackup.inPlace nil) -}}
{{- .Values.restoreFromBackup.inPlace -}}
{{- else if and (or (include "rondb.global.managedObjectStorage" (dict "global" .Values.global)) (include "rondb.global.minio" (dict "global" .Values.global))) .Values.global._hopsworks.restoreFromBackup .Values.global._hopsworks.restoreFromBackup.inPlace -}}
{{- .Values.global._hopsworks.restoreFromBackup.inPlace -}}
{{- end -}}
{{- end -}}

{{- define "rondb.restoreFromBackup.forceDataClear" -}}
{{- if not (eq .Values.restoreFromBackup.forceDataClear nil) -}}
{{- .Values.restoreFromBackup.forceDataClear -}}
{{- else if and (or (include "rondb.global.managedObjectStorage" (dict "global" .Values.global)) (include "rondb.global.minio" (dict "global" .Values.global))) .Values.global._hopsworks.restoreFromBackup .Values.global._hopsworks.restoreFromBackup.forceDataClear -}}
{{- .Values.global._hopsworks.restoreFromBackup.forceDataClear -}}
{{- end -}}
{{- end -}}

{{- define "rondb.restoreFromBackup.isInPlace" -}}
{{- if eq (include "rondb.restoreFromBackup.inPlace" .) "true" -}}
  {{- if not (include "rondb.isUpgrade" .) -}}
    {{- fail "\n\nERROR: restoreFromBackup.inPlace=true is only supported during 'helm upgrade'.\nAn in-place restore replaces data in an existing cluster and cannot be used during a fresh install.\nTo create a new cluster from a backup, set restoreFromBackup.inPlace=false.\n" -}}
  {{- end -}}
  {{- if not (include "rondb.restoreFromBackup.backupId" .) -}}
    {{- fail "\n\nERROR: restoreFromBackup.inPlace=true requires a backup ID.\nPlease set: --set-string restoreFromBackup.backupId=<backup-id> or global._hopsworks.restoreFromBackup.backupId=<backup-id> \n" -}}
  {{- end -}}
  {{- if ne (include "rondb.restoreFromBackup.forceDataClear" .) "true" -}}
    {{- fail "\n\nERROR: restoreFromBackup.inPlace=true requires explicit acknowledgment that existing data will be destroyed.\nPlease set: --set restoreFromBackup.forceDataClear=true\n\nWARNING: This will permanently delete all existing data in the cluster!\n" -}}
  {{- end -}}
true
{{- else if and (include "rondb.isUpgrade" .) (include "rondb.restoreFromBackup.backupId" .) -}}
  {{- fail "\n\nERROR: restoreFromBackup.backupId is set during an upgrade but restoreFromBackup.inPlace is not enabled.\n\nIf you intend to restore a backup into this cluster, set:\n  --set restoreFromBackup.inPlace=true --set restoreFromBackup.forceDataClear=true\nOr globally:\n  --set global._hopsworks.restoreFromBackup.inPlace=true --set global._hopsworks.restoreFromBackup.forceDataClear=true\n\nIf you are performing a normal upgrade and do not intend to restore, clear the backup ID:\n  --set-string restoreFromBackup.backupId=\nOr globally:\n  --set-string global._hopsworks.restoreFromBackup.backupId=\n" -}}
{{- end -}}
{{- end -}}

{{- define "rondb.backups.metadataStore.configMapName" -}}
{{- if .Values.backups.metadataConfigmapName -}}
{{- .Values.backups.metadataConfigmapName  -}}
{{- else if and (include "rondb.global.backupsEnabled" .) .Values.global._hopsworks.backups.metadataStore.configMap.ronDB -}}
{{- .Values.global._hopsworks.backups.metadataStore.configMap.ronDB -}}
{{- end -}}
{{- end -}}

{{- define "rondb.backups.pathScheme" -}}
{{- if or (eq .Values.backups.objectStorageProvider "s3") (include "rondb.global.managedObjectStorage.s3" (dict "global" .Values.global)) (include "rondb.global.minio"  (dict "global" .Values.global)) -}}
{{- "s3:/" -}}
{{- end -}}
{{- end -}}

{{- define "rondb.backups.ttl" -}}
{{- if .Values.backups.ttl -}}
{{- .Values.backups.ttl  -}}
{{- else if and (include "rondb.global.backupsEnabled" .) .Values.global._hopsworks.backups.ttl -}}
{{- .Values.global._hopsworks.backups.ttl -}}
{{- end -}}
{{- end -}}

{{- define "rondb.shouldExecute2410Migration" -}}
{{- $execute := true -}}
{{- $sts := lookup "apps/v1" "StatefulSet" .Release.Namespace .Values.meta.mgmd.statefulSetName -}}
{{- if $sts -}}
  {{- $containers := get $sts.spec.template.spec "containers" -}}
  {{- if $containers -}}
    {{- range $c := $containers -}}
      {{- if eq $c.name "mgmd" -}}
        {{- $imageSplits := regexSplit ":+" $c.image -1 -}}
        {{- $tag := last $imageSplits -}}
        {{- $majorStr := regexFind "^[0-9]+" $tag -}}
        {{- if $majorStr -}}
          {{- if ge ($majorStr | int) 24 -}}
            {{- $execute = false -}}
          {{- end -}}
        {{- else -}}
          {{- $execute = $.Values.mysql.force2410UserGrantMigration -}}
        {{- end -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
{{- else -}}
  {{- $execute = .Values.mysql.force2410UserGrantMigration -}}
{{- end -}}
{{- if $execute -}}
true
{{- end -}}
{{- end -}}

{{/*
rest_api.json is mounted with subPath, which never live-updates: without a
hash of the rendered file in the pod template, a values change touching only
the REST config (rdrs.maxKeepaliveRequests, rdrs.uploadPath, ...) updates the
ConfigMap and rolls nothing.
*/}}
{{- define "rondb.restApiHash" -}}
{{ tpl ($.Files.Get "files/configs/rest_api.json") $ | sha256sum }}
{{- end -}}

{{/*
The set keys of one rest_api.json section, as `"JSONKey": value` lines joined
by ",\n" plus the indent of the section's keys (8 for a top-level section).
Usage: {{ include "rondb.rdrs.configFields" (dict
    "values" $.Values.rdrs.internal
    "keys" (list (list "maxBuffers" "MaxBuffers") ...)
    "indent" 8) }}

A null value renders nothing, and the caller renders the section only when
this returns something: RDRS images that predate a key reject it at startup
("Unexpected key"), so a key stays out of the file until it is set. Values
go through toJson so bools, integers and strings render as their JSON type.
"values" may be nil: Helm deletes null-valued keys before rendering, so a
section whose keys are all null may be missing altogether.
*/}}
{{- define "rondb.rdrs.configFields" -}}
{{- $values := .values | default dict -}}
{{- $fields := list -}}
{{- range $pair := .keys -}}
{{- $value := index $values (first $pair) -}}
{{- if not (eq $value nil) -}}
{{- $fields = append $fields (printf "\"%s\": %s" (last $pair) (toJson $value)) -}}
{{- end -}}
{{- end -}}
{{- join (printf ",\n%s" (repeat (.indent | int) " ")) $fields -}}
{{- end -}}

{{/*
terminationGracePeriodSeconds for one component.
Usage: {{ include "rondb.gracePeriod" (dict "v" $.Values "component" "ndbmtds") }}

Before the per-component object the value was a single integer that only
the data nodes applied; every other pod ran with the Kubernetes default of
30s. Customers re-supply their values files on upgrade, so the integer form
keeps rendering with exactly that meaning. A null (the Helm idiom for
dropping an override) must fall back to the defaults: Helm deletes null keys
before schema validation, so `| int` on the missing value would otherwise
render 0, which the kubelet floors to ~2s.
*/}}
{{- define "rondb.gracePeriod" -}}
{{- $default := 30 -}}
{{- if eq .component "ndbmtds" -}}{{- $default = 300 -}}{{- end -}}
{{- $g := .v.terminationGracePeriodSeconds -}}
{{- if kindIs "map" $g -}}
{{- index $g .component | default $default | int -}}
{{- else if eq .component "ndbmtds" -}}
{{- $g | default $default | int -}}
{{- else -}}
30
{{- end -}}
{{- end }}

{{/*
preStop drain for daemons behind a Service: endpoint removal and SIGTERM
start concurrently on pod delete, and these daemons stop within seconds of
SIGTERM, before kube-proxy and load balancers have dropped the endpoint.
Keeping the pod serving for 5s (out of its grace budget) while the removal
propagates avoids refused connections during rolling restarts.
*/}}
{{- define "rondb.lifecycle.preStopDrain" -}}
lifecycle:
  preStop:
    exec:
      command: ["/bin/sleep", "5"]
{{- end }}

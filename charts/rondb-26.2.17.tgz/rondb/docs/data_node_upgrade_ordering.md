# Ordering data node StatefulSet rollouts during upgrades

Status: implemented and shipped — commit `[RONDB-1089] 4e54bd8`, PR
[logicalclocks/rondb-helm#213](https://github.com/logicalclocks/rondb-helm/pull/213)
against `branch-26.02`. Gated behind `ndbmtdSequencedRollout.enabled`
(default off).

Implementation:

- `templates/ndbd.yaml` — the partition freeze on the node-group
  StatefulSets
- `templates/ndbmtd_sequenced_rollout.yaml` — the rollout CronJob (+ its
  ServiceAccount/Role/RoleBinding)
- `templates/shared_templates/_helpers.tpl` —
  `rondb.ndbmtdSequencedRollout.isActive` (single gate for freeze and
  CronJob together: flag on, more than one node group, not externally
  managed, not an in-place restore) and
  `rondb.ndbmtdSequencedRollout.perGroupStallTimeoutMinutes` (derived
  stall threshold)
- `values.schema.json` → `ndbmtdSequencedRollout` (source of truth;
  `values.yaml` regenerated via `json_to_yaml.py`)
- `test_scripts/sequenced-rollout-test.sh` — rendering gates + the CronJob
  script executed against a fake kubectl (97 assertions); wired into the
  CI lint job, no cluster needed

The chart code and schema are self-documenting and carry no references to
this document. Shipped comments and messages use plain wording ("rollout",
"run") — this document keeps some design-analysis terms ("walker",
"level-triggered") when comparing alternatives.

Revision history:

- **Rev 9 (current)** — fixed the health gate's self-block deadlock,
  demonstrated on hardware 2026-09-01, with the fixed behaviour verified on
  hardware 2026-09-02 as part of a superset change (which additionally
  deleted the dead pod itself; that deletion performed no repair on a
  pre-1.35 controller, so what was measured is the behaviour of this
  revision). The Rev 8 gate computed one all-groups health boolean, so
  a frozen group that was pending *and* unhealthy disqualified itself from
  being unfrozen — and since every `helm upgrade` re-freezes all groups
  (three-way merge restores the rendered partition), the upgrade carrying a
  fix for a bad build re-froze the broken group and then held its repair
  forever, logging "another group is unhealthy" when no other group was
  unhealthy. Fix: hold only on groups other than the unfreeze target and name
  them in the log; prefer a pending group that is itself unhealthy over lower
  healthy ones (the update is usually its repair; rolling it adds no
  exposure); and unfreeze it only when the controller would replace its dead
  pod first — never when the highest not-yet-updated ordinal is alive while
  another pod is down, which would cost an already degraded group a live
  replica. That safety walk mirrors the controller: highest ordinal first,
  stopping at an updated-but-unavailable pod exactly where the controller
  itself waits, with "unavailable" meaning the controller's own notion (Ready
  *and* not terminating). Pod reads in the walk fail closed — only NotFound
  counts as "gone". Cross-group health also consults a one-call census of
  terminating pods, because `status.readyReplicas` counts a Ready-but-
  terminating pod that the controller already treats as unavailable.

  Delivering the update is left to the StatefulSet controller, which deletes
  the highest-ordinal pod not on the update revision as soon as the group is
  unfrozen. **This relies on `podManagementPolicy: Parallel`**, which the
  node-group StatefulSets set. Under `OrderedReady` the controller returns
  early on any pod that is terminating or not Running+Ready and never reaches
  that deletion — the documented "forced rollback" case, where the bad pod
  must be deleted by hand. See "Controller versions where unfreezing is not
  enough" below for the one controller version that behaves the same way.
- **Rev 8** — corrected the idle-wake mechanism for Helm 4.
  Rev 7 rendered `suspend: false` and relied on Helm's client-side three-way
  merge to reset live drift; Helm 4 defaults to **server-side apply**, under
  which a field the chart declares *and* the run mutates has two owners, and
  Helm's apply fails with a `.spec.suspend` conflict (a `kubectl patch` is an
  Update, a distinct owner from an Apply even under the same field-manager
  name, so matching managers does not help). Fix: `.spec.suspend` is no longer
  templated — Helm never owns it — and a `post-upgrade,post-rollback` hook Job
  (`rondb-ndbmtd-sequenced-rollout-wake`) patches it back to `false`, rendered
  under the same gate as self-suspend so it is absent under Argo.

- **Rev 7** — the CronJob now suspends itself when idle
  (`suspendWhenIdle`, default on): zero pods between rollouts, woken by
  the next helm upgrade/rollback (the chart rendered `suspend: false`
  explicitly so Helm's three-way patch restored it — mechanism superseded by
  Rev 8). Gated off when
  `mode` is set — the Argo CD convention — where Argo's sync would either
  fight the suspension or, told to ignore it, never wake the CronJob.
  Documented trade-off: changes applied outside Helm while suspended wait
  for the next helm operation or a manual unsuspend.

- Rev 6 — dropped Kubernetes Event emission entirely (the
  remaining `Unfroze`/`Converged`/`Stalled` Events, the heredoc that built
  them, the `events` RBAC rule, and the stall-dedup annotation). Events
  expire after ~1 hour by default, so they only covered the first hour of
  an incident while the durable signals — the StatefulSet fields, the
  CronJob logs (which re-print a stalled group's state on every run), and
  the revision-age metric alert — carry everything. Down to one
  annotation (the unfroze-at stall timer).

- Rev 5 — simplified the reconciler, trimming observability
  that the revision-age metric alert already covers: removed the
  `SequencedRolloutBlocked` event and its two dedup annotations (a rollout
  held by an unhealthy frozen group is now logged, not evented — the safety
  gate that prevents degrading two groups at once is unchanged), the
  `SequencedRolloutComplete` event (completion is `updateRevision ==
  currentRevision` on every group), and the `observedGeneration` stale
  guard (its strong justification left with the canary in Rev 4; for the
  level-triggered loop a stale read only causes one self-correcting
  re-freeze/unfreeze cycle). Down to two annotations and a linear post-scan
  decision. Core algorithm and the `SequencedRolloutStalled` event unchanged.

- Rev 4 — dropped the optional canary gate (`canaryGroups`
  value + `ndbmtd_sequenced_rollout_canary.yaml`). It reintroduced the very
  awaited-post-upgrade-hook paradigm Rev 3 rejected, doubled the bash
  surface (the canary's own script with its `observedGeneration`-race,
  `podFailurePolicy`, and `activeDeadlineSeconds` edge cases), and its
  fail-fast-on-bad-image value was already covered by the revision-age
  metric alert or an operator/CI running `kubectl rollout status
  node-group-0` after the upgrade. It was purely additive and off by
  default, so it can be re-added verbatim if in-band fail-fast is ever
  actually requested. The core freeze + reconciler is unchanged.

- Rev 3 — the walker moved from awaited post-upgrade hooks to a
  level-triggered CronJob reconciler. Trigger: scale analysis. Node-group
  recovery is data-dependent and can take hours; at 10+ node groups the walk
  is tens of hours, and no synchronous `helm upgrade` can span that (beyond
  `--timeout`, a helm process *killed* mid-hook — dropped SSH, CI runner
  limit — leaves the release stuck in `pending-upgrade`, requiring manual
  surgery; over a multi-hour window interruption is near-certain). The
  freeze mechanism is unchanged from Rev 2; only where the walker runs
  changed.
- Rev 2 — recommendation changed from a pre-upgrade apply-hook to
  partition-gated rollout (freeze + walk). The pre-upgrade hook made a hook
  Job a second writer of the node-group manifests; see Alternatives §1.
- Rev 1 — pre-upgrade hook Job applying node groups sequentially.

## Problem

The chart renders one StatefulSet per node group (`node-group-0..N-1`, see
`templates/ndbd.yaml`). On `helm upgrade`, Helm stamps all of them at once and
each StatefulSet rolls independently. There is no Kubernetes primitive that
orders rollouts *across* objects, so up to one data node from **every** node
group restarts concurrently.

What already works correctly today:

- **Within a node group**: the StatefulSet controller rolls one pod at a time
  (ordinal-descending), and the startup/readiness probes gate on the NDB node
  actually reaching *started* state by querying the MGMd directly and failing
  closed: an unreachable MGMd or any answer other than an explicit `started`
  reports not-ready. This gate is the ONLY thing preventing a node group from
  losing both replicas to a rolling update (`podManagementPolicy: Parallel`
  affects only scaling, not updates) — the earlier `healthcheck.sh`-based
  probes failed *open* when the MGMd was unreachable, and a crash-looping pod
  reported Ready during an MGMd roll let the controller take down the healthy
  peer, shutting the whole cluster down by arbitration (recorded live
  2026-08-27). `healthcheck.sh` remains only in the liveness probe, whose
  fail-open polarity is deliberate: never kill a data node just because the
  MGMd is away. See `test_scripts/probe-fail-closed-test.sh` for the probe
  contract.
- **Tier ordering (MGMd first)**: `templates/mgmd_pre_upgrade.yaml` is a
  pre-upgrade hook Job that applies the rendered MGMd manifests and waits for
  convergence before the main Helm apply, so MGMd rolls before everything
  else. (Its rollout is minutes and its scope is one small StatefulSet — the
  scale argument below does not apply to it. It stays as-is.)

What is missing — and what sequencing node groups would buy:

- **Blast-radius containment**: today a bad image takes down one node in every
  group simultaneously (the whole cluster at single-replica exposure at once).
  Sequenced, a bad image stops at the first group and the other groups never
  start rolling.
- **Bounded recovery load**: N simultaneous node restarts means N simultaneous
  recoveries syncing from their group peers.
- Note: the current concurrent behavior is *data-safe* in NDB terms (one node
  per group at a time is a documented rolling-restart pattern). Sequencing is
  about exposure windows and fail-fast containment, not a correctness bug.

## Hard requirements

1. **Feature flag.** The entire feature is gated behind a single value
   (default **off**). Flag off ⇒ the rendered manifests and upgrade behavior
   are byte-identical to today.
2. **Single writer.** Helm's main apply remains the only thing that writes
   the node-group StatefulSet manifests. Orchestration may only touch the
   one field that controls *when the controller acts*
   (`updateStrategy.rollingUpdate.partition`) — never the spec itself.
3. **Fail-safe.** Any orchestration failure must leave every group either
   fully converged or untouched-and-running on the old revision. "Nothing
   happened" must be the failure mode, not "half happened".
4. **No effect** on fresh install, in-place restore
   (`restoreFromBackup.inPlace`), externally-managed clusters, or
   single-node-group clusters (with one group there is nothing to sequence
   across — and `numNodeGroups` is immutable after install, so the
   condition is stable for the cluster's life).
5. **Scale.** A node-group roll can take hours (recovery is data-dependent)
   and clusters can have 10+ groups: the full walk is potentially **tens of
   hours**. No design may require a single synchronous process (a `helm`
   command, a hook watch, one long-lived Job pod) to span the whole walk.

## The design space

Every possible solution pulls one of three levers:

1. **When the new spec reaches each StatefulSet** — pre-upgrade hook,
   deployment-tool ordering (Argo waves, Flux `dependsOn`, CI pipelines).
   Rejected: it requires a second applier of the manifests (Alternatives §1).
2. **When the controller may act on a spec it already has** —
   `updateStrategy.rollingUpdate.partition`, `updateStrategy: OnDelete`.
   **This is the chosen lever**: spec delivery stays on the normal Helm path.
3. **When individual pods may die or start** — admission webhooks,
   preStop/init-container gating. Rejected (Alternatives §6): can't order
   terminations, or operationally hostile.

Within lever 2 there is a second axis — *where the walker runs*: awaited
hooks (edge-triggered, blocks the release), a fire-and-forget Job
(edge-triggered, async), or a reconciler (level-triggered, async).
Requirement 5 eliminates awaited hooks; the plain Job is strictly worse than
both (see "Where the walker runs" below). Level-triggered wins.

## Recommended: partition-frozen StatefulSets + level-triggered reconciler

### Mechanism — freeze (unchanged from Rev 2)

When the flag is on, each node-group StatefulSet renders:

```yaml
updateStrategy:
  type: RollingUpdate
  rollingUpdate:
    partition: {{ .Values.clusterSize.activeDataReplicas }}
```

The StatefulSet controller only acts on ordinals `>= partition`, so
`partition == replicas` is a total freeze: `helm upgrade` applies **all**
node-group specs atomically through the normal path, and nothing restarts.
The pending update is visible as `updateRevision != currentRevision` on each
StatefulSet — plain, inspectable Kubernetes state, no custom bookkeeping.

- `helm upgrade --wait` does not hang on frozen StatefulSets: Helm's
  readiness checker requires `updatedReplicas >= replicas - partition`
  (trivially true) and only compares revisions when `partition == 0`. Argo
  CD's StatefulSet health check is partition-aware the same way. (Both are
  version-dependent implementation details — the shipped test covers
  rendering and CronJob behavior, not this; still worth pinning in the
  lifecycle workflow against the Helm version in use.)
- Fresh install is unaffected: on creation `currentRevision ==
  updateRevision`, so the partition is irrelevant until the first upgrade.
- Fail-safe falls out for free: if the rollout CronJob never runs, the
  cluster keeps running the old revision indefinitely with the update
  parked. Nothing is half-applied, ever.

### Mechanism — the rollout CronJob (Rev 3 shape, simplified in Rev 5)

A **rollout CronJob** — a normal chart resource on the normal apply path,
rendered together with the partition field (never one without the other),
running every few minutes (`concurrencyPolicy: Forbid`;
`startingDeadlineSeconds: 300` so a long controller-manager outage can never
trip Kubernetes' 100-missed-start-times cutoff and permanently stop
scheduling; `successfulJobsHistoryLimit: 1`; every kubectl call bounded by
`--request-timeout` and the whole run by `activeDeadlineSeconds`). Each run
is idempotent, takes seconds, and holds almost no state of its own — the
partition value and `currentRevision`/`updateRevision` live on the
StatefulSets, plus one annotation the CronJob stamps to time a stalled
group (an unfroze-at timestamp):

```
scan ALL groups (ascending), classifying each:
  pending = updateRevision != currentRevision
  frozen  = partition >= replicas
  healthy = readyReplicas == replicas

during the scan:
  unfrozen + converged (not pending, healthy):
      re-freeze (partition = replicas), clear the annotation
  unfrozen + not yet converged:
      the rollout is busy — nothing else may unfreeze this run;
      adopt it (stamp unfroze-at) if the annotation is missing or invalid;
      past perGroupStallTimeoutMinutes log the stall (every run)

after the scan, if nothing is unfrozen:
  target = lowest pending frozen group that is itself unhealthy,
           else the lowest pending frozen group
  some OTHER group unhealthy:
      hold (log only, naming the unhealthy groups) so the rollout never
      degrades two groups at once — the target's own health does not
      count against it, or a broken group could never receive a fix
  target unhealthy and the update would NOT replace its dead pod first
  (highest not-yet-updated ordinal is alive, or an already-updated pod
  above it is unavailable — the pending revision is itself the poison and
  the controller would wait there too, or every pod is already updated):
      hold (log only) — unfreezing would either delete a live pod from an
      already degraded group or achieve nothing
  otherwise:
      unfreeze the target (partition = 0), stamp unfroze-at.
      The controller then deletes the highest-ordinal pod not on the
      update revision — for a sick target that is its dead pod — and
      recreates it on the update revision, carrying the fix.
```

Properties:

- **At most one group unfrozen at any time** — the same exposure bound as
  the hook design, enforced per run against observed state rather than by
  process control flow.
- **Nothing long-running exists.** The rollout spans hours because the
  *StatefulSet controller* spends hours rolling pods between runs — no helm
  process, hook watch, or Job pod has to survive the duration. A killed
  run, drained node, or restarted control plane costs nothing; the next
  run re-reads reality and continues. Requirement 5 is met by
  construction.
- **Rollback needs no hooks at all.** `helm rollback` (or `--atomic`) simply
  creates new pending updates; the CronJob rolls them out the same way —
  including replacing a crash-looping half-upgraded pod once its group is
  unfrozen (the pod no longer matches the update revision). Working from
  current state also covers what no hook ever could: out-of-band spec
  changes (a manual `kubectl apply`, an Argo sync outside a Helm operation).
- **Stall = containment, not rollback.** A group that won't converge (bad
  image) pauses the rollout — no further groups are unfrozen — and stays
  unfrozen, re-logged on every run. Deliberate: re-freezing wouldn't heal the
  crash-looping pod (the controller never reverts a live pod below the
  partition). Note the group does NOT stay unfrozen across the next helm
  operation: every `helm upgrade` — the fix included, and even a re-apply of
  identical values — writes the rendered (frozen) partition back over the
  live value (the same three-way-merge behaviour the idle-wake design relies
  on). Delivering the fix therefore depends on the unfreeze decision, which
  is why a pending group's own sickness must not hold it (next bullet); Rev 8
  and earlier deadlocked here, demonstrated on hardware 2026-09-01.
- **Held while any OTHER group is unhealthy.** A pending update is not
  started while some other group has unready pods, so the rollout never
  degrades two groups at once; the hold log names the unhealthy groups.
  Health is the controller's notion, not `status.readyReplicas` alone:
  that field (and `availableReplicas`) still counts a Ready pod that is
  terminating, while the rolling update treats it as unavailable — so
  each run takes a one-call census of terminating data pods and counts
  their groups unhealthy. The
  target's own health does not count against it: a group broken by a bad
  build can only be repaired by the update it is waiting for. A pending
  group that is itself unhealthy is preferred over lower healthy ones
  (rolling it adds no new exposure, and the update is often the repair), but
  only when the controller would replace its dead pod first — if the highest
  not-yet-updated ordinal is alive while another pod is down, unfreezing
  would delete a live replica, so the run holds and says so. This is a
  log-only hold (Rev 5); the revision-age metric is the "not progressing"
  signal.
- **Take-over-and-re-freeze semantics.** Any unfrozen group — including one
  an operator unfroze by hand — is taken over: the CronJob stamps its
  unfroze-at annotation, watches it converge, and re-freezes it. Manual
  unfreezes are therefore temporary by design; the way to keep a group
  unmanaged is disabling the flag, not hand-editing the partition.

### Controller versions where unfreezing is not enough

Unfreezing a group is the whole repair on every controller that deletes the
highest-ordinal outdated pod for us. Two cases do not, and both need one
manual step:

- **Kubernetes 1.35.0 with `MaxUnavailableStatefulSet` enabled.** That gate
  shipped beta/on in 1.35.0 and its path refuses every deletion in a group
  that already has an unavailable pod — not even the dead old-revision pod
  (kubernetes/kubernetes#137409; the gate was disabled again in later 1.35
  patch releases; the underlying bug is tracked in that issue). The group is
  unfrozen and honestly stalled. Recovery: with the group at partition 0,
  `kubectl delete pod node-group-$g-$r` for the dead pod; its replacement is
  created on the update revision and carries the fix. The gate is *alpha and
  off* on 1.33 and 1.34, so this affects only 1.35.0-vintage control planes.
- **`podManagementPolicy: OrderedReady`.** Not used by this chart, but worth
  naming: the controller returns early on any unready pod and never reaches
  the deletion at all. Same manual step.

A third case is version-independent: a pod stuck in `Terminating` (typically a
lost node) is skipped by the controller, and a plain `kubectl delete` is a
no-op on it. It needs `kubectl delete pod --force --grace-period=0`, or the
node object removing, before the roll can continue.

### Known behaviour: two sick groups stall each other

If two groups are unhealthy at once and both are pending, the target is the
lower one and the higher one is its blocker, so nothing rolls until one is
repaired — the log names the blocker. This is the gate working as intended
(unfreezing a group while another is degraded is exactly what it forbids),
not the self-block deadlock returning. Recovery is to repair either group, by
whatever the fault needs; the rollout resumes on the next reconcile. Observed
on hardware 2026-09-02: the rollout resumed 54 s after the blocking group's
infrastructure fault was cleared.

### The trade-off: release success ≠ rollout success

Because the rollout is asynchronous, `helm upgrade` succeeding means "intent
recorded, rollout in progress" — a bad image does not fail the release, and
completion must be observed on the cluster instead. This is by design (see
Requirement 5: no synchronous process can span a tens-of-hours rollout), and
it is mitigated, not eliminated:

- **Metrics** catch both a stalled rollout and a stopped CronJob: alert on
  `kube_statefulset_status_update_revision !=
  kube_statefulset_status_current_revision` with an age threshold (see
  Observability). This is the recommended in-fleet signal.
- **Manual / CI check**: an operator or pipeline that wants an explicit
  first-group gate can run `kubectl rollout status statefulset/node-group-0`
  after `helm upgrade` returns — no chart machinery required. Whole-cluster
  completion is `updateRevision == currentRevision` on every node group.

(An earlier revision shipped an optional in-release canary hook for this;
it was removed in Rev 4 — see the revision history for why, and for how to
re-add it if in-band fail-fast is ever required.)

### Where the walker runs — why level-triggered beats both hook variants

**Awaited post-upgrade hooks** (Rev 2) are the right shape only when the
total walk fits inside a timeout an operator will actually hold open. They
give per-group `--timeout` windows and release-outcome fidelity — but at
10 groups × hours, the helm command must survive tens of hours. Timeout
leaves a FAILED release with later hooks never created (safe but parked);
process death leaves `pending-upgrade` (manual surgery); interruption
probability over such a window approaches 1. The fidelity they exist to
provide becomes unearnable exactly at the scale this chart targets.
Rejected. (An earlier revision kept their one benefit — in-release
fail-fast on the first group — as an optional canary hook; Rev 4 removed it
in favor of metrics/CI checks. See the revision history.)

**A plain fire-and-forget release Job** is strictly worse than both other
options and is rejected outright:

- All release resources are created at once — nothing orders per-group
  Jobs, so it degenerates to one monolithic looping Job: a single pod that
  must survive the entire multi-hour walk (violates Requirement 5, modulo
  Job-controller retries).
- Failures are silent: release **deployed**, Argo **synced**, `--atomic`
  never triggers, CD remediation sees success — while the walker died at
  group 0 and pods sit frozen-old with no diff pressure. Unreported
  containment defeats fail-fast.
- Rollback is nondeterministic: `helm rollback` replays the stored manifest
  naming the *old revision's* Job; whether the walk re-runs depends on
  whether `ttlSecondsAfterFinished` already garbage-collected it.
- Job immutability forces revision-suffixed names and TTL GC fiddliness.

The rollout CronJob keeps the plain Job's fast-returning release while
fixing everything else: runs are short-lived (nothing to keep alive),
failures pause the rollout in observable API state rather than silence, and
rollback/out-of-band changes are handled by construction rather than by
hook annotations.

### Steady-state cost — what happens between rollouts

With `suspendWhenIdle` (the default, active under plain Helm and Flux) the
CronJob suspends itself once everything is converged: **zero pods run
between rollouts**. Under Argo CD (`mode` set) it stays always-on instead —
there an idle run is one short-lived pod doing `numNodeGroups` kubectl
reads and exiting in seconds (at the 3-minute default roughly 1–2
CPU-minutes per day, `successfulJobsHistoryLimit: 1` keeping clutter at a
single completed Job), and `reconcileIntervalMinutes` (e.g. 10–15) is the
lever if that churn matters: between rollouts the CronJob only needs to
catch rollbacks and out-of-band changes, where minutes of detection
latency are irrelevant.

How the idle behavior was chosen: two designs were analyzed. Both must
survive Helm 4's default apply mode — **server-side apply (SSA)** — which
changes what "Helm resets the rendered value" means. Under SSA a field is
owned by the `(manager, operation)` that last wrote it: the chart's upgrade
is an **Apply** as manager `helm`, while a `kubectl patch` from the run is an
**Update** — a *distinct* owner even when it reuses the same manager name. So
if the chart both **declares** `.spec.suspend` and the run **patches** it,
the next `helm upgrade` Apply collides with the run's Update owner and fails
with a `.spec.suspend` conflict. (This is not the Helm 3 client-side
three-way merge an earlier draft reasoned about, where the rendered value
silently overwrote live drift — SSA turns that same overwrite into a hard
conflict.) The rule that falls out: **a field the run mutates at runtime must
not be templated**, so Helm never owns it.

**Implemented (Rev 8, `suspendWhenIdle`, default on): the CronJob suspends
itself when idle; a Helm hook wakes it.**

- `.spec.suspend` is **not** rendered in the CronJob manifest, so Helm never
  owns the field and cannot conflict with the run's patch. A new CronJob
  defaults to `suspend: false`, so a fresh install runs immediately.
- The run that finds every group converged and frozen patches its own
  CronJob to `suspend: true` (a plain Update) — idle cost drops to zero pods.
- A `post-upgrade,post-rollback` hook Job
  (`rondb-ndbmtd-sequenced-rollout-wake`) patches `suspend: false` once after
  every helm operation, so a new rollout always wakes at full speed. It runs
  once and is deleted
  (`hook-delete-policy: before-hook-creation,hook-succeeded`); because it can
  only ever un-suspend and never overlaps the reconcile run, it cannot leave
  the CronJob asleep. Flux helm-controller performs real Helm upgrades and
  triggers the hook the same way. A run started by hand from a suspended
  CronJob (`kubectl create job --from=...`) that finds work also resumes the
  schedule itself.
- **Gated off when `mode` is set** — the chart's existing Argo CD convention
  (the same signal `rondb.canUseLookupFunc` keys on, via
  `rondb.ndbmtdSequencedRollout.suspendWhenIdleActive`). There self-suspend is
  off **and** the wake hook is not rendered: the CronJob simply stays
  scheduled and no-ops when idle, so nothing ever writes `.spec.suspend` and
  there is no conflict to resolve. (Argo would otherwise translate the
  `helm.sh/hook` annotations into a PostSync Job — avoided by not rendering
  it.) The suspend logic only activates when `mode` is unset or `auto` (Helm
  CLI, Flux).
- **Accepted trade-off**: a spec change applied outside Helm (a manual
  `kubectl apply` to a node-group StatefulSet) while suspended stays
  frozen until the next Helm operation or a manual wake —
  `kubectl patch cronjob rondb-ndbmtd-sequenced-rollout --type merge -p
  '{"spec":{"suspend":false}}'`. The revision-age metric alert
  (Observability) is the safety net for this case; the value description
  states it loudly. Set `suspendWhenIdle: false` to keep the CronJob
  always running instead.
- Runner-up, kept as the fallback if the out-of-band gap bites in
  practice: a **two-speed schedule** (idle runs patch `.spec.schedule` to
  a slow cadence, any run that sees work patches it back; Argo-safe and
  self-recovering within one idle interval). The margin is small — at a
  daily idle cadence, two-speed is within one short pod-run per day of
  suspend — so the choice favors zero idle activity over automatic
  self-recovery. (Under SSA this alternative needs the same untemplating
  treatment for `.spec.schedule` that suspend now gets, for the same
  two-owner reason. And plain two-speed beats *exponential* backoff either
  way: idle cost is flat, so extra backoff states buy nothing.)

### Failure & recovery playbook

- **Bad image**: the rollout pauses at the first affected group — that
  group at single-replica with a crash-looping pod, all later groups
  frozen-old, the stall logged on every run. Fix values → `helm upgrade` →
  new spec lands everywhere and **re-freezes every group, the stalled one
  included** (three-way merge restores the rendered partition); the next
  reconcile then unfreezes the broken group in preference to the healthy
  ones — its dead pod is the highest not-updated ordinal, so the controller
  replaces that pod first — and the rollout resumes. No zombie processes,
  no release-state surgery. (On a 1.35.0 control plane with
  `MaxUnavailableStatefulSet` on, delete the dead pod by hand once the group
  is unfrozen; see "Controller versions where unfreezing is not enough".)
  To also restore the group's redundancy without waiting for the roll,
  delete the crash-looping pod *after* the upgrade:
  it comes back on `currentRevision` (the working build), never touching
  the healthy pod. Delete-the-pod alone, without the fixed upgrade, loops —
  the sequencer re-applies the still-bad pending revision.
- **Roll back instead**: `helm rollback` — pending updates in the old
  direction; the CronJob rolls them out; the bad pod is replaced when its
  group is unfrozen. (NDB caveat, inherent to any downgrade: a node that
  partially ran the new binary may have written newer on-disk structures
  and can need a node `--initial` start to rejoin on the old version.)
- **CronJob broken/misbehaving**: the mechanism is one integer per
  StatefulSet. Manual escape: `kubectl patch sts node-group-$i -p
  '{"spec":{"updateStrategy":{"rollingUpdate":{"partition":0}}}}'` per
  group, in order, by hand — or disable the flag (see Values: pending
  updates then roll concurrently, i.e. today's behavior). Caveat: only
  unfreeze a degraded group by hand when its *down* pod is the highest
  not-yet-updated ordinal; otherwise the controller replaces a live pod
  first and the group briefly has no replica at all (the same check the
  reconcile run makes before unfreezing an unhealthy group).
- **Rollback to a pre-feature revision**: drops the partition field and the
  CronJob → partition defaults to 0 → concurrent roll, exactly today's
  behavior. Acceptable.

### Interactions that must be designed in

- **In-place restore** (`templates/backups/inplace_restore.yaml`): its
  weight `-5` pre-upgrade Job scales every node-group StatefulSet to 0.
  Pods created at ordinals `< partition` come up on **currentRevision** —
  the *old* template — so a frozen scale-up from zero would resurrect old
  pods without `FORCE_INITIAL_START`/`INPLACE_BACKUP_ID` and break the
  restore. Hence: when `rondb.restoreFromBackup.isInPlace`, one shared gate
  (`rondb.ndbmtdSequencedRollout.isActive`) suppresses the partition and the
  rollout CronJob together for that release.
- **Frozen-recreation semantics**: any pod recreated while its group is
  frozen — eviction, node failure, replica scale-up — comes back on
  `currentRevision`. Mid-upgrade that is the currently-running version,
  which is exactly right; a replica scale-up concurrent with a pending
  update briefly starts an old-template pod that converges when its group
  is unfrozen.
- **Argo CD selfHeal will fight the rollout.** An unfrozen group is drift
  against the rendered `partition: replicas`; with `selfHeal: true` Argo
  re-freezes it mid-roll. Ship documented `ignoreDifferences` for
  `.spec.updateStrategy.rollingUpdate.partition` on `node-group-*`
  StatefulSets (standard practice for partition-based rollouts), **plus the
  `RespectIgnoreDifferences=true` sync option** — `ignoreDifferences` alone
  only suppresses the OutOfSync signal; without the sync option Argo still
  pushes the rendered `partition` on every sync and re-freezes the rolling
  group. Flux helm-controller: drift detection is off by default; if enabled,
  the same field exclusion is needed. The CronJob tolerates the fight
  gracefully (a re-frozen group is just re-unfrozen next run), but the
  tug-of-war wastes a roll step — configure the exclusion. See "Deploying
  under Argo CD" below for the full Application spec.
- **Consecutive upgrades mid-rollout**: the newest spec lands (frozen) on
  all frozen groups; the one currently-unfrozen group rolls straight to the
  newest revision (exposure bounded to that group); the rollout continues
  against the new target. Working from current state makes "upgrade during
  an upgrade" a non-event rather than a special case. One SSA wrinkle: while
  a group is unfrozen the run holds its `partition` at 0, a different owner
  from Helm's rendered `partition: replicas`, so a `helm upgrade` launched
  *during* an active roll conflicts on that one StatefulSet — pass
  `--force-conflicts` for that (rare) case; it re-freezes the group and the
  next reconcile tick re-unfreezes the lowest pending group. At rest every
  group's `partition` equals the rendered value, so ordinary upgrades never
  conflict. (`partition` must stay templated — it establishes the freeze on
  install — so it can't be untemplated the way `.spec.suspend` is.)
- **Topology immutability**: `numNodeGroups` changes are already rejected at
  weight `-30/-20` (`templates/topology-immutability.yaml`), so the
  CronJob may assume the group count; missing StatefulSets (Argo first
  sync, destructive `forceNodeGroupChange=true` path) are simply skipped.
- **Tier ordering**: MGMd still rolls first (existing weight-10 pre-upgrade
  hook, unchanged — minutes-long, arbitration-critical). The API tier
  (MySQLds, RDRS) rolls during the main apply, before the data-node rollout
  — strictly fewer moving parts than today's everything-at-once, and NDB
  supports mixed adjacent versions; if canonical `mgmd → ndbmtd → api`
  order is ever required, the same freeze+rollout extends to the API-tier
  StatefulSets. Out of scope for v1.

### Deploying under Argo CD

Three pieces of Application config are needed. The chart already handles the
`.spec.suspend` half: with `mode` set it disables self-suspend and does not
render the wake hook, so nothing ever writes `.spec.suspend` and there is no
conflict there. What remains is the `partition` field, which the CronJob
mutates at runtime and Argo will otherwise fight.

1. **Set `mode`** (any non-`auto` value, e.g. `upgrade`) so the chart takes
   its Argo path: self-suspend off, wake hook not rendered, CronJob stays
   scheduled and no-ops when idle.
2. **`ignoreDifferences` on `partition`** for the node-group StatefulSets, so
   selfHeal does not re-freeze a rolling group. Argo's `ignoreDifferences`
   matches `name` exactly (no globbing), so enumerate one entry per group —
   `node-group-0 … node-group-<numNodeGroups-1>`. `numNodeGroups` is immutable
   after install, so this list is set once.
3. **`RespectIgnoreDifferences=true`** so Argo also skips *applying* the
   rendered `partition` on sync. Without it, `ignoreDifferences` only hides
   the OutOfSync signal and each sync still pushes `partition: replicas`,
   re-freezing the rolling group.

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
spec:
  source:
    helm:
      valuesObject:
        mode: upgrade
        ndbmtdSequencedRollout:
          enabled: true
  syncPolicy:
    automated:
      selfHeal: true
    syncOptions:
    - RespectIgnoreDifferences=true
  # One entry per node group (name has no wildcard support). For a 3-group
  # cluster: node-group-0, node-group-1, node-group-2.
  ignoreDifferences:
  - group: apps
    kind: StatefulSet
    name: node-group-0
    jsonPointers:
    - /spec/updateStrategy/rollingUpdate/partition
  - group: apps
    kind: StatefulSet
    name: node-group-1
    jsonPointers:
    - /spec/updateStrategy/rollingUpdate/partition
  - group: apps
    kind: StatefulSet
    name: node-group-2
    jsonPointers:
    - /spec/updateStrategy/rollingUpdate/partition
```

Notes:

- **Higher steady-state cost than plain Helm.** With self-suspend off the
  CronJob keeps ticking every `reconcileIntervalMinutes` even when idle (a
  few-second pod each time). Raise `reconcileIntervalMinutes` (e.g. 10–15) if
  that churn matters — idle detection latency is irrelevant between rollouts.
- **The `unfroze-at` annotation.** The CronJob stamps
  `rondb.hopsworks.ai/sequenced-rollout-unfroze-at` on a rolling StatefulSet.
  If your setup flags it as OutOfSync, add a
  `/metadata/annotations/rondb.hopsworks.ai~1sequenced-rollout-unfroze-at`
  pointer to each group's entry (`~1` is the JSON-pointer escape for `/`).
  Most setups will not need it.
- **Verify** by pushing a chart change and watching groups roll one at a time
  in the Argo UI without a group snapping back to frozen mid-roll — that is
  the signal `RespectIgnoreDifferences` is working.

### Values

Schema-first (`values.schema.json` → `json_to_yaml.py`):

- `ndbmtdSequencedRollout.enabled` — default `false`. Gates the partition
  field and the rollout CronJob together (via
  `rondb.ndbmtdSequencedRollout.isActive`). Takes effect
  only with more than one node group — with a single group there is nothing
  to sequence across (the StatefulSet controller already rolls it one pod
  at a time), so the chart behaves exactly as if the flag were off; since
  `numNodeGroups` is immutable after install, the condition is stable.
  **Disable semantics**: removing the field resets partition to 0 — any
  *pending* frozen update then rolls all groups concurrently (today's
  behavior). Document: disable during a quiet period or after confirming no
  update is pending.
- `ndbmtdSequencedRollout.reconcileIntervalMinutes` — CronJob run
  interval, default 3 (schema bounds 1–30). Adds at most one interval of
  latency per group boundary (~N × interval over a full rollout — noise
  against hours-long rolls). A no-op run is a seconds-long pod; history
  limits stay tight. **Why the 30 cap**: the schedule renders as
  `*/N * * * *`, and cron's `*/N` on the minutes field resets at every
  hour boundary — it fires at minutes 0, N, 2N… *within each hour*. Any
  N > 30 silently lies about the interval (`*/45` fires at :00 and :45 —
  alternating 45- and 15-minute gaps); intervals above 30 minutes are not
  expressible in this pattern at all. 30 is the largest value the
  mechanism can honor evenly. (Below 30, only divisors of 60 are perfectly
  even; non-divisors like 7 have one shorter gap per hour — harmless.)
- `ndbmtdSequencedRollout.suspendWhenIdle` — default `true`. The CronJob
  suspends itself once every group is converged and frozen; a
  `post-upgrade,post-rollback` hook Job wakes it after each helm operation
  (see "Steady-state cost" for why `.spec.suspend` is untemplated rather than
  reset by Helm). Only takes effect when `mode` is unset or `auto`; with
  `mode` set (Argo CD) both the self-suspend and the wake hook are off and the
  CronJob stays always-on. While suspended, changes applied outside Helm wait
  for the next helm operation or a manual
  `kubectl patch cronjob rondb-ndbmtd-sequenced-rollout --type merge -p
  '{"spec":{"suspend":false}}'`.
- `ndbmtdSequencedRollout.perGroupStallTimeoutMinutes` — stall-detection
  threshold; `0` (the default) derives it rather than inventing a number:
  `activeDataReplicas × timeoutsMinutes.ndbmtdStartupProbe` minutes plus
  30 minutes of slack (the startup probe already defines how long one node
  may take; a group is `replicas` of those, serially). This is an alerting
  threshold, not a process timeout — nothing is killed when it fires.

### Observability

The rollout's entire state is first-class API state, no custom store:

- Progress: `partition` + `currentRevision`/`updateRevision` per
  StatefulSet (document a `kubectl get sts -o custom-columns=...`
  one-liner). Pending-parked, mid-roll, stalled, and complete are all
  distinguishable from those fields.
- Logs: every run prints each group's state, and a stalled or held rollout
  is re-logged on every run — so the newest CronJob pod log always shows
  why the rollout is paused. (Kubernetes Events were dropped in Rev 6:
  they expire after ~1 hour by default, so they only ever covered the
  first hour of an incident, duplicating what the fields, the logs, and
  the alert below provide durably — for ~35 lines of bash and an extra
  RBAC rule.)
- Alerting: pair `kube_statefulset_status_update_revision !=
  kube_statefulset_status_current_revision` with an age threshold
  (kube-state-metrics) — catches both stalls and a stopped CronJob, closing
  the silent-failure gap that async operation opens.

## Alternatives considered

### 1. Pre-upgrade hook Job applying node groups sequentially (Rev 1 — rejected)

Extend the `mgmd_pre_upgrade.yaml` pattern: render per-group manifests into a
hook ConfigMap; a weight-20 pre-upgrade Job loops `kubectl apply` →
`rollout status` per group, so the main apply later sees no diff. Attractive
on paper (canonical `mgmd → ndbmtd → api` order, idempotent resume), but it
structurally adds a **second writer of the same objects to the upgrade
path**:

- **Dual-writer divergence.** The hook's client-side `kubectl apply` and
  Helm's stored-manifest three-way patch must produce byte-identical pod
  templates forever. On the adoption upgrade the live objects have no
  `last-applied` annotation, so an upgrade that *removes* a pod-template
  field rolls every group once via the hook and then a second time,
  **concurrently**, when the main apply prunes the field — defeating the
  feature exactly when it's needed.
- **Cluster state runs ahead of the release record**; a failure at group
  *i* leaves live state matching neither revision, recorded nowhere.
- **Hook coupling**: breaks in-place restore outright (the weight `-5`
  shutdown Job scales groups to zero; the weight-20 apply would resurrect
  them mid-restore).
- **No rollback story**: pre-upgrade hooks don't fire on `helm rollback`,
  so rollback reverts everything concurrently — including MGMd ordering
  (the Error 2305 arbitration hazard) — precisely during bad-image
  recovery.
- **Blocks the release for the whole walk** — fails Requirement 5 outright,
  independent of everything above.

### 2. Awaited post-upgrade hook walker (Rev 2 — rejected)

Per-group post-upgrade + post-rollback hook Jobs (unfreeze → `rollout
status` → re-freeze), serialized by hook weight. Keeps Helm as the single
manifest writer and makes release outcome equal rollout outcome — the right
design **when the total walk fits inside a `--timeout` an operator will
hold open**. It fails Requirement 5: at hours per group × 10+ groups the
helm process must survive tens of hours; timeout parks the walk with later
hooks never created, process death leaves `pending-upgrade`, and
interruption over such a window is near-certain. Its unique benefit —
in-release fail-fast on a bad image — was carried for one revision as an
optional canary hook bounded to the first group(s), then removed in Rev 4
(the same benefit comes from the revision-age metric alert or a CI
`kubectl rollout status node-group-0` check, without a second mechanism).

### 3. Always-on sequencer Deployment

Same level-triggered logic as the recommended CronJob, as a persistent
controller: instant reactions (no tick latency), watch-based. Costs an
always-running component to version, secure, and debug — for a walk that
happens a few times a year, tick latency of minutes is irrelevant against
hours-long rolls. The CronJob is the same logic at near-zero steady-state
cost; promote to a Deployment (or a real operator, §8) only if reaction
latency or richer orchestration ever matters.

### 4. `updateStrategy: OnDelete` + orchestrator Job deleting pods in order

Maximal control, but it reimplements the StatefulSet update controller in
bash: comparing `controller-revision-hash` to `updateRevision`, handling
pods created mid-orchestration, mixed-revision states if the Job dies, and
`kubectl rollout status` stops being meaningful. Partition-gating strictly
dominates it. **Rejected.**

### 5. Collapse all node groups into one StatefulSet

One StatefulSet with `numNodeGroups × replicas` pods and ordinal →
node-group mapping computed at startup. Kubernetes would then provide a
total order natively — but a StatefulSet has a *uniform* pod template, so
per-group labels are lost, and with them the per-group required
anti-affinity ("replicas of the same node group on different hosts"),
per-group storage sizing, and per-group headless Services.
**Architecturally blocked**, but explains why the chart has this problem at
all.

### 6. Deployment-tool ordering

- **Argo CD sync waves** per node-group StatefulSet: declarative and
  resumable, but Helm-CLI users get nothing — at best a complement. (An
  Argo sync holding waves open for tens of hours has its own operation-
  duration problems.)
- **Split into per-group releases** ordered externally (Flux `dependsOn`,
  CI running `helm upgrade --wait` per group): relocates the orchestrator
  into CI — same logic, worse cohesion, and the CI pipeline now must span
  the multi-hour walk.
- **Third-party workload CRDs** (OpenKruise `UnitedDeployment`): maps well,
  but a CRD/controller dependency in a general-purpose chart is a big ask.

### 7. Pod-level self-coordination — listed to close the space, not to use

- **Init-container lease gating**: orders *starts*, not *terminations* —
  controllers still kill one pod per group simultaneously; the dead pods
  then queue on the lock, holding *every* group at single-replica exposure
  for the full serialized duration. Strictly worse than today.
- **preStop gating**: capped by `terminationGracePeriodSeconds`, defeated
  by force-deletes and node failures.
- **Validating admission webhook** rejecting out-of-order pod deletions:
  the only pod-level mechanism that can order terminations, but it sits on
  the pod-deletion critical path (`failurePolicy: Fail` bricks the
  namespace when the webhook is down; `Ignore` voids the guarantee).
  Operationally hostile.

### 8. PodDisruptionBudgets

Worth adding per node group (`maxUnavailable: 1`) for node drains anyway,
but PDBs do **not** apply to StatefulSet rolling updates (the controller
deletes pods directly rather than through the eviction API), so they don't
solve this.

### 9. A real operator

The textbook long-term answer (cf. MySQL's ndb-operator): a reconcile loop
owning cluster-aware restarts, upgrade order across tiers, and failure
recovery. A product-scale investment. Note the recommended design *is* a
minimal reconcile loop — frozen manifests plus a level-triggered walker —
so it inherits an operator's key robustness properties and is the natural
seed of one.

## Decision summary

| Approach | Ordering | Fail-safe default | Survives tens-of-hours walks | Rollback | Main cost |
|---|---|---|---|---|---|
| Partition + CronJob reconciler (**recommended**) | Yes | Frozen — failure = nothing moves | Yes — no long-lived process exists | Level-triggered, automatic | Release ≠ rollout (mitigate: metrics / CI rollout-status check) |
| Partition + awaited post-upgrade hooks (Rev 2) | Yes | Frozen | **No** — helm must span the walk | Sequenced via `post-rollback` | Multi-hour blocking release; `pending-upgrade` on process death |
| Pre-upgrade apply hook (Rev 1) | Yes | No — applies immediately | No | Unsequenced, loses MGMd ordering | Dual-writer divergence; hook coupling |
| Plain release Job walker | Yes | Frozen | No — one pod spans the walk | Nondeterministic (TTL GC) | Silent failures |
| Always-on sequencer Deployment | Yes | Frozen | Yes | Level-triggered | Steady-state component |
| OnDelete + pod-deleting Job | Yes | No | No | Manual | Reimplements the controller |
| Single StatefulSet | Yes (native) | — | Yes | Native | Breaks per-group scheduling/storage |
| Argo sync waves | Yes | — | Poorly (long sync operations) | Argo-managed | Tool-coupled |
| Pod-level gating | Partial/none | — | — | — | Can't order terminations / hostile |

The freeze (partition rendering, flag, in-place gate, Argo
`ignoreDifferences`) is common to every partition-based row — it is the
stable foundation. The walker's runtime is the only variable, and
Requirement 5 (tens-of-hours walks) forces it to be level-triggered.
